# os-sample-java-web
Sample Java Web Application for use in OpenShift
